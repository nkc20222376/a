using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Main : MonoBehaviour
{

    string[][] answers;
    string[][] questions;

    public Button[] buttons;
    public Text[] question;
    string currentSceneName;

    
    
    //�I����
    string[] answers1 = 
    {"answer1",�@
     "answer2",
     "answer3",
     "answer4" };

    string[] answers2 = 
    {"answer1",
     "answer2",
     "answer3", };

    //���
    string[] questions1 = 
    {"Q1", "Q2",
     "Q3","Q4" };    

    Text[] textObjects = new Text[4];


    // Start is called before the first frame update
    void Start()
    {
        questions = new string[][] { questions1 };
        answers = new string[][] { answers1, answers2 };
        currentSceneName = SceneManager.GetActiveScene().name;�@//���[�h���̃V�[�������擾

        GetButton();//addListener�Ŏ擾�����{�^���̃N���b�N�����Ƃ������[�h�B
        GetText();         //����\��
    }
    public int n = 0,m=0;
    void GetButton()
    {
        if (currentSceneName == "SampleScene")
        {
            n = answers[0].Length;
            m = 0;
        }
        else
        {
            n = answers[1].Length;
            m = 1;
        }
        for (int i = 0; i < n; i++)
        {
            int index = i;
            if (m==0)
            {
                buttons[i].onClick.AddListener(() => Q1(index));
                question[0].text = questions[0][0];
                n = answers[0].Length;
            }
            else if (m==1)
            {
                buttons[3].gameObject.SetActive(false);
                buttons[i].onClick.AddListener(() => Q2(index));
                question[1].text = questions[0][1];
                n= answers[1].Length;                
            }          
        }      
    }    
    void GetText()
    {            
        textObjects[0] = GameObject.Find("T1").GetComponent<Text>();    //button1
        textObjects[1] = GameObject.Find("T2").GetComponent<Text>();    //2
        textObjects[2] = GameObject.Find("T3").GetComponent<Text>();    //3
        if (m!=1)
        {
            textObjects[3] = GameObject.Find("T4").GetComponent<Text>(); //4     
        }       

        System.Random rng = new System.Random();        
        
        while (n > 1)
        {
            n--;
            int k = rng.Next(n + 1);
            string value = answers[m][k];
            answers[m][k] = answers[m][n];
            answers[m][n] = value;
        }
        if (currentSceneName =="SampleScene")
        {
            n = answers[0].Length;
        }
        else
        {
            n = answers[1].Length;
        }

        for (int i = 0; i < n; i++)
        {            
            textObjects[i].text = answers[m][i];            
        }
    }

    void Q1(int buttonIndex)
    {
        if (textObjects[buttonIndex].text == "answer1")
        {
            LoadScene("Scene1");               
        }        
        else
        {
            Debug.Log("miss");        }
    }
    void Q2(int buttonIndex)
    {
        if (textObjects[buttonIndex].text == "answer2")
        { 
            LoadScene("Scene2");
        }
        else
        {
            Debug.Log("miss");
        }        
    }
    /*
      void ���(int buttonIndex)
    {
        if (textObjects[buttonIndex].text == "�����̉�")
        {
            LoadScene("Scene1");���������̖��
        }
        else
        {
            Debug.Log("miss");�@�s����
        }
    }
    */
    void LoadScene(string sceneName)
    {
        // �V�[���̓ǂݍ���
        SceneManager.LoadScene(sceneName);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
